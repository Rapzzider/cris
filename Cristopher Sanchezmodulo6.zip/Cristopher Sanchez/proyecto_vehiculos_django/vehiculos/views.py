from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required, permission_required
from django.shortcuts import render, redirect
from .models import Vehiculo
from .forms import VehiculoForm

def permission_denied_view(request, exception=None):
    return render(request, 'vehiculos/403.html', status=403)

def index(request):
    return render(request, 'vehiculos/index.html')


@login_required  # Solo los usuarios autenticados pueden acceder
@permission_required('vehiculos.visualizar_catalogo', raise_exception=True)
def listar_vehiculos(request):
    vehiculos = Vehiculo.objects.all()
    precios = []

    for vehiculo in vehiculos:
        if vehiculo.precio < 10000:
            condicion_precio = 'Bajo'
        elif 10000 <= vehiculo.precio <= 30000:
            condicion_precio = 'Medio'
        else:
            condicion_precio = 'Alto'
        
        precios.append({
            'vehiculo': vehiculo,
            'condicion_precio': condicion_precio,
        })
        
    return render(request, 'vehiculos/listar.html', {'precios': precios})

@login_required
@permission_required('vehiculos.agregar_vehiculo', raise_exception=True)
def agregar_vehiculo(request):
    if request.method == 'POST':
        form = VehiculoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar')
    else:
        form = VehiculoForm()
    return render(request, 'vehiculos/agregar.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('index')  
    else:
        form = AuthenticationForm()
    return render(request, 'vehiculos/login.html', {'form': form})



def user_logout(request):
    logout(request)
    return redirect('index') 