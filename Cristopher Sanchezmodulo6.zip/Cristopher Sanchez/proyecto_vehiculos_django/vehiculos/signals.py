from django.contrib.auth.models import Permission
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User
from django.contrib.contenttypes.models import ContentType
from .models import Vehiculo

@receiver(post_save, sender=User)
def assign_permissions(sender, instance, created, **kwargs):
    if created:
        # Asignar permisos adicionales si es necesario
        visualizar_catalogo_permission = Permission.objects.get(codename='visualizar_catalogo')
        instance.user_permissions.add(visualizar_catalogo_permission)

        