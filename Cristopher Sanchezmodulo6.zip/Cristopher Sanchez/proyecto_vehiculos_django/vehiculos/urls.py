from django.urls import path
from . import views
from django.conf.urls import handler403
from .views import permission_denied_view

handler403 = permission_denied_view

urlpatterns = [
    path('', views.index, name='index'),
    path('vehiculo/add/', views.agregar_vehiculo, name='add'),
    path('vehiculo/listar/', views.listar_vehiculos, name='listar'),
    path('login/', views.user_login, name='login'), 
    path('logout/', views.user_logout, name='logout'),  
]
